#ifndef __RM_NOISE_H__
#define __RM_NOISE_H__

void rm_noise1(int TD[30][1000],int row,int colu,int N);
void rm_noise2(int TD[30][1000],int row,int colu,int N);

#endif
